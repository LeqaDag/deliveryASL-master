package com.example.sajeda_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
