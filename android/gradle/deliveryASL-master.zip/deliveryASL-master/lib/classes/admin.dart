import 'package:flutter/cupertino.dart';

class Admin {
  String uid;
  String name;
  int phoneNumber;
  String email;
  String password;
  bool type;

  bool isArchived;
  DateTime deleteDate;
  String deleteUser;

  Admin({
    this.uid,
    @required this.name,
    @required this.phoneNumber,
    @required this.email,
    @required this.password,
    @required this.type,
    this.isArchived = false,
    this.deleteDate ,
    this.deleteUser,
  });
}
