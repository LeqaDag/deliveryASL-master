import 'package:flutter/cupertino.dart';

class Business {
  String uid;
  String name;
  int phoneNumber;
  String email;
  String password;

  bool isArchived;
  DateTime deleteDate;
  String deleteUser;

  Business({
    this.uid,
    @required this.name,
    @required this.phoneNumber,
    @required this.email,
    @required this.password,
    this.isArchived = false,
    this.deleteDate ,
    this.deleteUser,
  });
}
