import 'package:flutter/cupertino.dart';

class Order {
  String uid;
  int price;
  List<int> totalPrice;
  bool type;
  String description;
  DateTime date;
  String note;

  bool isLoading;
  bool isReceived;
  bool isUrgent;
  bool iscancelld;
  bool isDone;

  String customerID;

  bool isArchived;
  DateTime deleteDate;
  String deleteUser;

  Order({
    this.uid,
    @required this.price,
    @required this.totalPrice,
    @required this.type,
    @required this.description,
    @required this.date,
    @required this.note,
    this.isLoading = true,
    this.isReceived = false,
    this.isUrgent = false,
    this.iscancelld = false,
    this.isDone = false,
    @required this.customerID,
    this.isArchived = false,
    this.deleteDate,
    this.deleteUser,
  });
}
