import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:sajeda_app/components/driverComponent/driversComponent/driveradmin.dart';
import 'package:sajeda_app/components/pages/drawer.dart';
import 'store_business.dart';
import 'package:sajeda_app/components/widgetsComponent/CustomWidgets.dart';
import '../../constants.dart';
import 'admin_orders.dart';

class AdminHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: Home(),
      ),
    );
  }
}

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    //var x = width*0.4;
    return Scaffold(
      drawer: AdminDrawer(),
      appBar: AppBar(
        title: Text("اسم الادمن",
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Amiri',
            )),
        centerTitle: true,
        backgroundColor: kAppBarColor,
      ),
      body: Stack(
        children: <Widget>[
          Container(
              width: width,
              height: height * 0.2,
              //color: Color(0xff9DB9CB),

              child: Center(
                  child: Image.asset(
                    "assets/delivery_master_blue.png",
                    width: width,
                    fit: BoxFit.fill,
                  ))),
          Center(
            child: Container(
                width: width * 0.8,
                height: height * 0.7,
                margin: EdgeInsets.only(top: height * 0.07),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(style: BorderStyle.solid, width: 1),
                  borderRadius: BorderRadius.circular(23),
                  boxShadow: [
                    BoxShadow(color: Colors.black54, spreadRadius: 1.5),
                  ],
                ),
                child: ListView(
                  children: <Widget>[
                    CustomBoxSize(height: 0.05),
                    Column(
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: <Widget>[
                            CustomContainer(
                                width: 0.28,
                                height: 0.15,
                                imagepath:
                                AssetImage("assets/CompanysAndStores.png"),
                                text: "الشركات",
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            StoreAndBusiness()),
                                  );
                                }),
                            CustomContainer(
                                width: 0.28,
                                height: 0.15,
                                imagepath: AssetImage("assets/OrdersBox.png"),
                                text: "الطرود",
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => AdminOrders()),
                                  );
                                }),
                          ],
                        ),
                        CustomBoxSize(height: 0.05),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: <Widget>[
                            CustomContainer(
                                width: 0.28,
                                height: 0.15,
                                imagepath: AssetImage("assets/Driver.png"),
                                text: "السائقون",
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => DriverAdmin()),
                                  );
                                }),
                            CustomContainer(
                                width: 0.28,
                                height: 0.15,
                                imagepath:
                                AssetImage("assets/DeliveryLine.png"),
                                text: "خطوط التوصيل",
                                onTap: () {
                                  //type your code here 4
                                }),
                          ],
                        ),
                        CustomBoxSize(height: 0.05),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(right: 25),
                              child: CustomContainer(
                                  width: 0.28,
                                  height: 0.15,
                                  imagepath:
                                  AssetImage("assets/Accounting.png"),
                                  text: "الحسابات المالية",
                                  onTap: () {
                                    //type your code here 5
                                  }),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                )),
          ),
        ],
      ),
    );
  }
}
