import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sajeda_app/components/widgetsComponent/CustomWidgets.dart';
import '../../constants.dart';
import 'admin_home.dart';
import 'admin_password_change.dart';
import 'package:sajeda_app/services/auth/auth.dart';
// import 'package:buy_it/widgets/custom_textfield.dart';
// widgets/admin_login_custom_text_field

class LoginAdmin extends StatefulWidget {
  static String id = "LoginScreen";

  @override
  _LoginAdminState createState() => _LoginAdminState();
}

class _LoginAdminState extends State<LoginAdmin> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: Home(),
      ),
    );
  }
}

class Home extends StatefulWidget {

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool monVal = false;
  bool tuVal = false;
  bool wedVal = false;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _success;
  String _email, _password;
  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    // double width = MediaQuery
    //     .of (context)
    //     .size
    //     .width;
    return Scaffold(
      backgroundColor: KAdminLoginMainColor,
      body: Form(
        key: _formKey,
        child: ListView(
          children: <Widget>[
            Image.asset("assets/delivery_logo.png"),

            TextFormField(
              validator: (input) {
                if(input.isEmpty) {
                  return "الرجاء ادخال البريد الالكتروني";
                }
              },
              onSaved: (input) => _email = input,
              decoration: InputDecoration(
                labelText: "البريد الالكتروني",
              ),
              obscureText: true,
            ),

            TextFormField(
              validator: (input) {
                if(input.isEmpty) {
                  return "الرجاء ادخال كلمة المرور";
                }
              },
              onSaved: (input) => _password = input,
              decoration: InputDecoration(
                labelText: "كلمة المرور",
              ),
              obscureText: true,
            ),

            CustomTextFormField(
                TextInputType.emailAddress, false,
                "البريد الالكتروني", Icon(Icons.email),

            ),
            SizedBox(
              height: height * 0.03,
            ),

            CustomTextFormField(TextInputType.visiblePassword, true,
                "كلمة المرور", Icon(Icons.lock)),
            SizedBox(
              height: height * 0.06,
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 90),
              child: Container(
                height: 55,
                child: FlatButton(
                  onPressed: () {
                    _signInWithEmailAndPassword();
                  },
                  color: kAdminLoginBackGroundButtonColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: Text(
                    "دخول",
                    style: TextStyle(
                      fontFamily: 'Amiri',
                      fontSize: 30,
                      color: kAdminLoginButtonColor,
                    ),
                  ),
                ),
              ),
            ), // flat button
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Checkbox(
                  //checkColor: Colors.green,
                  activeColor: kCheckBoxActiveColor,
                  value: monVal,
                  onChanged: (bool value) {
                    setState(() {
                      monVal = value;
                    });
                  },
                ),
                Text(
                  "تذكير الحساب             ",
                  style: TextStyle(
                      fontFamily: 'Amiri',
                      fontSize: 18,
                      fontWeight: FontWeight.bold),
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => AdminPasswordChange()),
                    );
                  },
                  child: Text(
                    "هل نسيت كلمة المرور؟",
                    style: TextStyle(
                        fontFamily: 'Amiri',
                        fontSize: 18,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            Image.asset("assets/delivery_master.png"),
          ],
        ),
      ),
    );
  }

  void _signInWithEmailAndPassword() async {
    final formState = _formKey.currentState;
    if(formState.validate()) {
      formState.save();
      AuthService _authService = AuthService();
      _authService.signIn(_email, _password);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => AdminHome()),
      );
    }
  }
}


