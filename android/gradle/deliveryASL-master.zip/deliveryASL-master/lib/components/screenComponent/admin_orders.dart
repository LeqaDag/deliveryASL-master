import 'package:flutter/material.dart';
import 'package:sajeda_app/components/orderComponent/store_add_new_order.dart';
import 'package:sajeda_app/components/pages/drawer.dart';
import 'pending_orders.dart';
import 'pickup_orders.dart';
import 'ready_orders.dart';
import 'return_orders.dart';
import 'urgent_orders.dart';

import 'package:sajeda_app/components/widgetsComponent/CustomWidgets.dart';
import '../../constants.dart';
import 'all_orders.dart';
import 'canceled_orders.dart';

class AdminOrders extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text("الطرود",
              style: TextStyle(
                fontSize: 20.0,
                color: Colors.white,
                fontFamily: 'Amiri',
              )),
          backgroundColor: kAppBarColor,
          centerTitle: true,
          actions: <Widget>[
            IconButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AddNewOders()),
                );
              },
              icon: Icon(Icons.add),
              color: Colors.white,
            )
          ],
        ),
        drawer: AdminDrawer(),
        body: ListView(
          padding: EdgeInsets.only(top: height * 0.03),
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                CustomContainerOrders(
                    width: 0.37,
                    height: 0.17,
                    imagepath: AssetImage("assets/LoadedOrders.png"),
                    text: "الطرود المحملة",
                    badgeColorAndContainerBorderColor:
                        KBadgeColorAndContainerBorderColorLoadingOrder,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => PendingOrders()),
                      );
                    }),
                CustomContainerOrders(
                    width: 0.37,
                    height: 0.17,
                    imagepath: AssetImage("assets/RecipientOrder.png"),
                    text: "الطرود المستلمة",
                    badgeColorAndContainerBorderColor:
                        KBadgeColorAndContainerBorderColorRecipientOrder,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => PickupOrders()),
                      );
                    }),
              ],
            ),
            CustomBoxSize(height: 0.05),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                CustomContainerOrders(
                    width: 0.37,
                    height: 0.17,
                    imagepath: AssetImage("assets/AllOrders.png"),
                    text: "حميع الطرود",
                    badgeColorAndContainerBorderColor:
                        KBadgeColorAndContainerBorderColorAllOrder,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => AllOrders()),
                      );
                    }),
                CustomContainerOrders(
                    width: 0.37,
                    height: 0.17,
                    imagepath: AssetImage("assets/UrgentOrders.png"),
                    text: "الطرود المستعجلة",
                    badgeColorAndContainerBorderColor:
                        KBadgeColorAndContainerBorderColorUrgentOrders,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => UrgentOrders()),
                      );
                    }),
              ],
            ),
            CustomBoxSize(height: 0.05),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                CustomContainerOrders(
                    width: 0.37,
                    height: 0.17,
                    imagepath: AssetImage("assets/ReadyOrders.png"),
                    text: "الطرود الجاهزة",
                    badgeColorAndContainerBorderColor:
                        KBadgeColorAndContainerBorderColorReadyOrders,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => ReadyOrders()),
                      );
                    }),
                CustomContainerOrders(
                    width: 0.37,
                    height: 0.17,
                    imagepath: AssetImage("assets/ReturnOrders.png"),
                    text: "الطرود الراجعة",
                    badgeColorAndContainerBorderColor:
                        KBadgeColorAndContainerBorderColorReturnOrders,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => ReturnOrders()),
                      );
                    }),
              ],
            ),
            CustomBoxSize(height: 0.05),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(right: 25),
                  child: CustomContainerOrders(
                      width: 0.37,
                      height: 0.17,
                      imagepath: AssetImage("assets/CancelledOrders.png"),
                      text: "الطرود الملغية",
                      badgeColorAndContainerBorderColor:
                          KBadgeColorAndContainerBorderColorCancelledOrders,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => CanceledOrders()),
                        );
                      }),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
