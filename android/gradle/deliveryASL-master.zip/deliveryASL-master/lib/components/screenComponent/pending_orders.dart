import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sajeda_app/components/pages/drawer.dart';

import 'package:sajeda_app/components/widgetsComponent/CustomWidgets.dart';
import '../../constants.dart';

class PendingOrders extends StatefulWidget {
  @override
  _PendingOrdersState createState() => _PendingOrdersState();
}

class _PendingOrdersState extends State<PendingOrders> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("الطرود المحملة",
            style: TextStyle(fontSize: 20.0, fontFamily: 'Amiri')),
        backgroundColor: kAppBarColor,
        centerTitle: true,
      ),
      endDrawer: Directionality(
          textDirection: TextDirection.rtl, child: AdminDrawer()),
      backgroundColor: Colors.white,
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(
          children: <Widget>[
            CustomCardAndListTile(color: KPendingListTileColor, onTapBox: null),
            CustomCardAndListTile(
                color: KPendingListTileColor, onTapBox: () {}),
            CustomCardAndListTile(color: KPendingListTileColor, onTapBox: null),
          ],
        ),
      ),
    );
  }
}
