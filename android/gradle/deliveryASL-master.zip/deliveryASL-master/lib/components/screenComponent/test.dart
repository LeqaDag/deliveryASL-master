
import 'package:flutter/material.dart';

class Test extends StatelessWidget {
   @override
   Widget build(BuildContext context) {
     return MaterialApp(

       home: Scaffold(
         appBar: AppBar(),


         body: Stack(
           children: <Widget>[
             Padding(
               padding: const EdgeInsets.all(100),
               child: Container(
                 width: 200,
                 height: 200,
                 decoration: BoxDecoration(
                   border: Border.all(),
                   color: Colors.red
                 ),


               ),
             ),

             Positioned(
               top: 40,
               right: 70
               ,
               child: Container(
                 width: 50,
                 height: 100,
                 decoration: BoxDecoration(
                     border: Border.all(),
                     color: Colors.green,
                    shape: BoxShape.circle,

                 ),
               ),
             ),
           ],
         ),


       ),

     );
   }
 }
