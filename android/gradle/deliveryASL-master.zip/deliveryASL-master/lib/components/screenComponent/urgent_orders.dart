import 'package:flutter/material.dart';
import 'package:sajeda_app/components/pages/drawer.dart';
import 'package:sajeda_app/components/widgetsComponent/CustomWidgets.dart';
import '../../constants.dart';

class UrgentOrders extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("الطورد المستعجلة",
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Amiri',
            )),
        backgroundColor: kAppBarColor,
        centerTitle: true,
      ),
      endDrawer: Directionality(
          textDirection: TextDirection.rtl, child: AdminDrawer()),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(
          children: <Widget>[
            CustomCardAndListTile(
                color: KUrgentOrdersListTileColor, onTapBox: null),
            CustomCardAndListTile(
                color: KUrgentOrdersListTileColor, onTapBox: null),
            CustomCardAndListTile(
                color: KUrgentOrdersListTileColor, onTapBox: null),
          ],
        ),
      ),
    );
  }
}
