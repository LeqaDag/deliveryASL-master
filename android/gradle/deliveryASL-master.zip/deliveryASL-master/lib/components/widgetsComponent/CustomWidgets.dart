import 'package:flutter/material.dart';

import '../../constants.dart';
import 'package:badges/badges.dart';

class CustomTextFormField extends StatelessWidget {
  final TextInputType keyboardInputType;
  final bool obscuretext;
  final String hinttext;
  final Icon icon;

  CustomTextFormField(
      this.keyboardInputType, this.obscuretext, this.hinttext, this.icon);
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    //double height = MediaQuery.of(context).size.height;
    return Container(
      margin: EdgeInsets.only(right: width * 0.08, left: width * 0.08),
      child: TextFormField(
        keyboardType: keyboardInputType,
        obscureText: obscuretext,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.only(right: 10.0, left: 10.0),
          hintText: hinttext,
          hintStyle: TextStyle(
            fontFamily: 'Amiri',
            fontSize: 18.0,
          ),
          prefixIcon: icon,
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(25),
            borderSide: BorderSide(
              color: Colors.black,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(40),
            borderSide: BorderSide(
              color: Colors.blue,
              width: 2,
            ),
          ),
        ),
      ),
    );
  }
}

class CustomBoxSize extends StatelessWidget {
  final double height;
  CustomBoxSize({@required this.height});

  @override
  Widget build(BuildContext context) {
    // double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    return SizedBox(
      height: height * this.height,
    );
  }
}

class CustomContainer extends StatelessWidget {
  final double height;
  final double width;
  final AssetImage imagepath;
  final String text;
  final Function onTap;
  CustomContainer(
      {@required this.width,
      @required this.height,
      @required this.imagepath,
      @required this.text,
      @required this.onTap});

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return InkWell(
      onTap: onTap,
      child: Container(
          height: height * 0.15,
          width: width * 0.28,

          //child: Image.asset("assets/OrdersBox.png"),
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(
                style: BorderStyle.solid, width: 1, color: Colors.grey),
            borderRadius: BorderRadius.circular(20),
            image: DecorationImage(
              image: imagepath,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.only(top: 80),
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                // fontWeight: FontWeight.bold,
                fontFamily: 'Amiri',
              ),
            ),
          )),
    );
  }
}

class CustomContainerOrders extends StatelessWidget {
  final double height;
  final double width;
  final AssetImage imagepath;
  final String text;
  final Function onTap;
  final Color badgeColorAndContainerBorderColor;
  CustomContainerOrders(
      {@required this.width,
      @required this.height,
      @required this.imagepath,
      @required this.text,
      @required this.badgeColorAndContainerBorderColor,
      @required this.onTap});

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return InkWell(
      onTap: onTap,
      child: Badge(
        elevation: 5,
        padding: EdgeInsets.all(9.0),
        animationType: BadgeAnimationType.scale,
        borderRadius: 50,
        badgeContent: Text(
          "0",
          style: TextStyle(color: Colors.white),
        ),
        badgeColor: badgeColorAndContainerBorderColor,
        position: BadgePosition.topStart(start: -5, top: -10.5),
        child: Container(
            height: height * this.height,
            width: width * this.width,
            //child: Image.asset("assets/OrdersBox.png"),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(
                  style: BorderStyle.solid,
                  width: 3,
                  color: badgeColorAndContainerBorderColor),
              borderRadius: BorderRadius.circular(20),
              image: DecorationImage(
                image: imagepath,
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.only(top: 90),
              child: Text(
                text,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 14,
                  // fontWeight: FontWeight.bold,
                  fontFamily: 'Amiri',
                ),
              ),
            )),
      ),
    );
  }
}

class CustomCardAndListTile extends StatelessWidget {
  final Color color;
  final Function onTapBox;
  CustomCardAndListTile({@required this.color, @required this.onTapBox});

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return Card(
      color: color,
      child: ListTile(
        title: Text("اسم الشركة"), // String Variable Take Name From DataBase

        leading: CircleAvatar(
            // Account Image Form DataBase
            ),
        trailing: Wrap(
          spacing: -15, // space between two icons
          children: <Widget>[
            Badge(
              position: BadgePosition.topStart(
                  start: width * 0.04, top: height * -0.004),
              elevation: 5,
              animationType: BadgeAnimationType.slide,
              badgeContent: Text(
                "0",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                ),
              ),
              shape: BadgeShape.circle,
              badgeColor: KEditIconColor,
              child: IconButton(
                  icon: Image.asset("assets/BoxIcon.png"), onPressed: onTapBox),
            ),
            IconButton(
                icon: Icon(Icons.edit, color: KEditIconColor), onPressed: null),
            IconButton(
                icon: Icon(Icons.delete, color: KTrashIconColor),
                onPressed: null),
          ],
        ),
      ),
    );
  }
}
