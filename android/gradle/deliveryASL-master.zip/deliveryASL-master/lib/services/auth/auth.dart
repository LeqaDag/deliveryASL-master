import 'package:firebase_auth/firebase_auth.dart';

class AuthService {

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  // signIn
  Future<String> signIn (String email, String password) async{
    try {
      return (await _firebaseAuth.signInWithEmailAndPassword(email: email, password: password)).uid;
    } catch(e) {
      print(e.message);
    }

  }

  // signOut
  signOut() {
    return _firebaseAuth.signOut();
  }
}
