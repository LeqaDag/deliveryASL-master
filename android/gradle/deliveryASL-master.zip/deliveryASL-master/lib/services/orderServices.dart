import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:sajeda_app/classes/order.dart';

class OrderService {
  final CollectionReference orderCollection =
      FirebaseFirestore.instance.collection('orders');

  Future<void> addOrderData(Order order) async {
    DocumentReference docReference = orderCollection.doc();
    await docReference.set({
      'price': order.price,
      'totalPrice': order.totalPrice,
      'type': order.type,
      'description': order.description,
      'date': order.date,
      'note': order.note,
      'isLoading': order.isLoading,
      'isReceived': order.isReceived,
      'isUrgent': order.isUrgent,
      'iscancelld': order.iscancelld,
      'isDone': order.isDone,
      'customerID': order.customerID,
      'isArchived': order.isArchived,
    });
  }

  Order _orderDataFromSnapshot(DocumentSnapshot snapshot) {
    return Order(
      price: snapshot.data()['price'],
      totalPrice: snapshot.data()['totalPrice'],
      type: snapshot.data()['type'],
      description: snapshot.data()['description'],
      date: snapshot.data()['date'],
      note: snapshot.data()['note'],
      isLoading: snapshot.data()['isLoading'],
      isReceived: snapshot.data()['isReceived'],
      isUrgent: snapshot.data()['isUrgent'],
      iscancelld: snapshot.data()['iscancelld'],
      isDone: snapshot.data()['isDone'],
      customerID: snapshot.data()['customerID'],
      isArchived: snapshot.data()['isArchived'],
    );
  }

  List<Order> _orderListFromSnapshot(QuerySnapshot snapshot) {
    return snapshot.docs.map((doc) {
      //print(doc.data());
      return Order(
        uid: doc.reference.id,
        price: doc.data()['price'] ?? '',
        totalPrice: doc.data()['totalPrice'] ?? '',
        type: doc.data()['type'] ?? '',
        description: doc.data()['description'] ?? '',
        date: doc.data()['date'] ?? '',
        note: doc.data()['note'] ?? '',
        isLoading: doc.data()['isLoading'] ?? '',
        isReceived: doc.data()['isReceived'] ?? '',
        isUrgent: doc.data()['isUrgent'] ?? '',
        iscancelld: doc.data()['iscancelld'] ?? '',
        isDone: doc.data()['isDone'] ?? '',
        customerID: doc.data()['customerID'] ?? '',
        isArchived: doc.data()['isArchived'] ?? '',
      );
    }).toList();
  }

  Stream<Order> get orderData {
    return orderCollection.doc().snapshots().map(_orderDataFromSnapshot);
  }

  Stream<List<Order>> get orders {
    return orderCollection
        .where('isArchived', isEqualTo: false)
        .snapshots()
        .map(_orderListFromSnapshot);
  }

  Future<void> deleteUserData(String uid) async {
    return await orderCollection.doc(uid).update({'isArchived': true});
  }
}
